<?php

return [
    'name' => 'Content',
];
