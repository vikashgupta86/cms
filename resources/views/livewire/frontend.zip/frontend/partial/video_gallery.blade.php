@if(isset($section) && $section->items && $section->items->count())
<section class="video-gallery-section py-5 bg-light">
    <div class="container">
        <h2 class="mb-4">Video Gallery</h2>

        <div class="row g-3">
            @foreach($section->items as $item)
                <div class="col-md-4">
                    <div class="video-card border rounded bg-white p-3 h-100">
                        @if(!empty($item->url))
                            <div class="ratio ratio-16x9 mb-2">
                                <iframe src="{{ $item->url }}"
                                        title="{{ $item->name }}"
                                        allowfullscreen></iframe>
                            </div>
                        @endif

                        <h5>{{ $item->name }}</h5>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
