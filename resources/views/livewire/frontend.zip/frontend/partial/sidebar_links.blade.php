@if(isset($section) && $section->items && $section->items->count())
<section class="right-sidebar-links-section py-4">
    <div class="container">
        <div class="row justify-content-end">
            <div class="col-md-4">
                <div class="border rounded p-3">
                    <h4 class="mb-3">{{ $section->title ?? 'Important Links' }}</h4>

                    <ul class="list-unstyled mb-0">
                        @foreach($section->items as $item)
                            @php
                                $href = $item->type === 'external'
                                    ? $item->url
                                    : ($item->type === 'file'
                                        ? asset('storage/' . ($item->file_path ?? $item->file ?? ''))
                                        : route('show.content', $item->slug));
                            @endphp

                            <li class="mb-2">
                                <a href="{{ $href }}"
                                   @if($item->opens_new_tab || $item->type === 'external' || $item->type === 'file') target="_blank" rel="noopener" @endif>
                                    {{ $item->name }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
@endif
