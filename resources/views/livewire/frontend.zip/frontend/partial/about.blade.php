<div class="container-fluid bg-light py-5">
    <div class="container">

        @foreach($items as $item)

            @if($item->type === 'content')

                <div class="row">

                    {{-- ABOUT SECTION --}}
                    <div class="col-md-8">

                        <div class="container py-4">

                            <h1 class="display-6 mb-4 text-primary">

                                @if($item->file_icon)
                                    <img
                                        class="ic_ht me-2"
                                        src="{{ asset('storage/'.$item->file_icon) }}"
                                        alt="{{ $item->name }}"
                                        style="height:50px;"
                                    >
                                @endif

                                {{ $item->name }}

                            </h1>

                            <p class="mb-4 text-justify text-dark">
                                {!! $item->content !!}
                            </p>

                            <div class="mt-3">
                                <a href="{{ route('show.content', $item->slug) }}"
                                   class="btn btn-primary rounded-pill py-2 px-4">
                                    View more ➜
                                </a>
                            </div>

                        </div>

                    </div>

                    {{-- CHILDREN / MINISTERS --}}
                    @foreach($item->children as $child)

                        <div class="col-md-2">

                            <div class="row team pb-5">
                                <div class="pb-2">

                                    <div class="row g-4">

                                        <div class="col-md-12">

                                            <div class="team-item border rounded overflow-hidden shadow-sm h-100">

                                                <div class="team-img">

                                                    @if($child->file)
                                                        <img
                                                            src="{{ asset('storage/'.$child->file) }}"
                                                            class="img-fluid w-100"
                                                            alt="{{ $child->name }}"
                                                            style="height:250px; object-fit:cover;"
                                                        >
                                                    @endif

                                                </div>

                                                <div class="team-content bg-light text-center p-2">

                                                    <h2 class="h5 mb-1">
                                                        {{ $child->name }}
                                                    </h2>

                                                    @if($child->description)
                                                        <p class="mb-0">
                                                            {{ $child->description }}
                                                        </p>
                                                    @endif

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </div>

                        </div>

                    @endforeach

                </div>

            @endif

        @endforeach

    </div>
</div>