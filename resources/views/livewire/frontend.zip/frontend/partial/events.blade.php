@if(isset($section) && $section->items && $section->items->count())
<section class="events-calendar-section py-5">
    <div class="container">
        <h2 class="mb-4">Events Calendar</h2>

        <div class="row g-3">
            @foreach($section->items as $item)
                <div class="col-md-4">
                    <div class="event-card border rounded p-3 h-100">
                        <h5>{{ $item->name }}</h5>

                        @if(!empty($item->description))
                            <p>{{ $item->description }}</p>
                        @endif

                        <a href="{{ route('show.content', $item->slug) }}">
                            View Details
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
