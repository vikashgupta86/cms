@if(isset($section) && $section->items && $section->items->count())
<section class="photo-gallery-section py-5">
    <div class="container">
        <h2 class="mb-4">Photo Gallery</h2>

        <div class="row g-3">
            @foreach($section->items as $item)
                <div class="col-6 col-md-3">
                    <div class="photo-card border rounded overflow-hidden h-100">
                        @if(!empty($item->image))
                            <img src="{{ asset('storage/' . $item->image) }}"
                                 alt="{{ $item->name }}"
                                 class="img-fluid w-100">
                        @endif

                        <div class="p-2">
                            <h6 class="mb-0">{{ $item->name }}</h6>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
