<div class="container-fluid wow zoomInDown announcement-wrapper"
     data-wow-delay="0.1s">

    <div class="row tickerpanle_maine">

        <div class="col-md-2 tickerpanle_maine_heading">
            Announcement
            <i class="fa fa-bullhorn ic_ht"></i>
        </div>

        <div class="col-md-9 Announcement_link">
            <div class="marquee-container">
                <div class="marquee-text">

                    @forelse($items as $item)

                        @php
                            if ($item->type === 'file' && $item->file) {
                                $url = asset('storage/' . $item->file);
                                $icon = '<i class="fa fa-file-pdf-o text-danger"></i>';
                            } elseif ($item->type === 'external' && $item->url) {
                                $url = $item->url;
                                $icon = '<i class="fa fa-external-link"></i>';
                            } else {
                                $url = route('show.content', $item->slug);
                                $icon = '';
                            }
                        @endphp

                        <a target="_blank" href="{{ $url }}">
                            ↠ {{ $item->name }} {!! $icon !!}
                        </a>

                        &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;

                    @empty
                        <span>No announcement found</span>
                    @endforelse

                </div>
            </div>
        </div>

        <div class="col-md-1 tickerpanle_maine_view">
            <a href="{{ route('show.content', 'announcement') }}">
                View All
            </a>
        </div>

    </div>
</div>

<style>.announcement-wrapper {
    background-color: #212121 !important;
    padding: 0;
}

.tickerpanle_maine {
    background: #000;
    color: #fff;
    min-height: 50px;
    display: flex;
    align-items: stretch;
    overflow: hidden;
    margin: 0;
}

.tickerpanle_maine_heading {
    background: #2b2b2b;
    color: #fff;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 12px;
    min-height: 50px;
}

.ic_ht {
    font-size: 18px;
    margin-left: 5px;
}

.Announcement_link {
    background: #000;
    overflow: hidden;
    display: flex;
    align-items: center;
    min-height: 50px;
    padding: 0;
}

.marquee-container {
    width: 100%;
    overflow: hidden;
    white-space: nowrap;
}

.marquee-text {
    display: inline-block;
    white-space: nowrap;
    padding-left: 100%;
    animation: announcement-marquee 35s linear infinite;
}

.marquee-text a {
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    line-height: 50px;
}

.marquee-text a:hover {
    color: #f5c542;
    text-decoration: underline;
}

.marquee-container:hover .marquee-text {
    animation-play-state: paused;
}

.tickerpanle_maine_view {
    background: #2b2b2b;
    color: #fff;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 50px;
    padding: 10px;
}

.tickerpanle_maine_view a {
    color: #fff !important;
    text-decoration: none !important;
}

.tickerpanle_maine_view a:hover {
    color: #f5c542 !important;
}

@keyframes announcement-marquee {
    0% {
        transform: translateX(0);
    }
    100% {
        transform: translateX(-100%);
    }
}</style>