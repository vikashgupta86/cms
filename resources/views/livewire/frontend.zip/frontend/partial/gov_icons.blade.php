@if(isset($items) && $items->count())
<div class="container-fluid px-0">
    <div class="row g-0 serviceicon_top">
        <div id="carouselExampleControls3" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner service_icon_top">
                @foreach($items->chunk(6) as $chunkIndex => $itemsChunk)
                    <div class="carousel-item {{ $chunkIndex == 0 ? 'active' : '' }}">

                        {{-- Force single row, no wrap --}}
                        <div class="d-flex flex-nowrap">
                            @foreach($itemsChunk as $loopIndex => $item)
                                @php
                                    $isFirst = ($chunkIndex == 0 && $loopIndex == 0);

                                    $href = match($item->type) {
                                        'external' => $item->url,
                                        'file'     => asset('storage/' . ($item->file ?? '')),
                                        default    => $item->url ?? 'pages/' . $item->slug,
                                    };

                                    $target = ($item->opens_new_tab || $item->type === 'external')
                                        ? '_blank'
                                        : '_self';

                                    $fileIcon = $item->file_icon ?? null;
                                    $icon     = $item->icon ?? null;
                                @endphp

                                <div class="service-icon-cell border-end {{ $isFirst ? 'active-item' : '' }}">
                                    <div class="p-3 text-center">
                                        <a href="{{ $href }}"
                                           target="{{ $target }}"
                                           @if($target === '_blank') rel="noopener" @endif>

                                            <div style="margin-bottom: 10px; min-height: 60px; display:flex; align-items:center; justify-content:center;">
                                                @if($fileIcon)
                                                    <img src="{{ asset('storage/' . $fileIcon) }}"
                                                         alt="{{ $item->name }}"
                                                         class="img-fluid"
                                                         style="max-height: 60px; max-width: 100%;">
                                                @elseif($icon && !Str::startsWith($icon, 'fa'))
                                                    <img src="{{ asset($icon) }}"
                                                         alt="{{ $item->name }}"
                                                         class="img-fluid"
                                                         style="max-height: 60px; max-width: 100%;">
                                                @elseif($icon)
                                                    <i class="{{ $icon }} fa-2x"></i>
                                                @else
                                                    <i class="fa fa-link fa-2x"></i>
                                                @endif
                                            </div>

                                            <h6 class="mb-0" style="font-size: 13px; line-height: 1.3;">
                                                {{ $item->name }}
                                            </h6>
                                        </a>
                                    </div>
                                </div>

                            @endforeach
                        </div>

                    </div>
                @endforeach

                
            </div>

            @if($items->count() > 6)
                <div class="servicion_carsousel">
                    <button class="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleControls3"
                            data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleControls3"
                            data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            @endif
        </div>
    </div>
</div>

{{-- <style>
    .service-icon-cell {
        flex: 0 0 16.6666%;   /* exactly 1/6 width = 6 per row */
        max-width: 16.6666%;
        min-width: 0;
    }

    .service-icon-cell a {
        display: block;
        color: inherit;
        text-decoration: none;
    }

    .service-icon-cell a:hover {
        text-decoration: none;
        opacity: 0.85;
    }

    /* First item dark highlight — matches image */
    .active-item {
        background-color: #1a2e4a;
    }

    .active-item a,
    .active-item h6 {
        color: #ffffff !important;
    }

    .active-item img {
        filter: brightness(0) invert(1);
    }

    .active-item i {
        color: #ffffff;
    }
</style> --}}
@endif