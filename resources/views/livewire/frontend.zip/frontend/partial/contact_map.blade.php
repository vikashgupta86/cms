@if(isset($section) && $section->menuItem)
<section class="contact-map-section py-5 bg-light">
    <div class="container">
        <h2 class="mb-3">{{ $section->menuItem->name }}</h2>

        @if(!empty($section->menuItem->content))
            <div class="mb-3">
                {!! $section->menuItem->content !!}
            </div>
        @endif

        @if(!empty($section->menuItem->custom_data['map_embed']))
            <div class="ratio ratio-16x9">
                {!! $section->menuItem->custom_data['map_embed'] !!}
            </div>
        @endif
    </div>
</section>
@endif
