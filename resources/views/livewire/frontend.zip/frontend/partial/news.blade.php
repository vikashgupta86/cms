@if(isset($items) && $items->count())

@php
    $tabs = $items->where('parent_id', null)->values();

    if ($tabs->count() === 0) {
        $tabs = $items->filter(function ($item) {
            return $item->children && $item->children->count();
        })->values();
    }
@endphp

<div class="col-md-8">
    <h1 class="display-6 mb-4 text-primary">
        <i class="fa fa-newspaper-o"></i> News & Events
    </h1>

    {{-- TABS --}}
    <ul class="nav nav-pills news-tabs mb-3" role="tablist">
        @foreach($tabs as $tab)
            <li class="nav-item flex-fill" role="presentation">
                <button
                    class="nav-link w-100 {{ $loop->first ? 'active' : '' }}"
                    id="news-tab-btn-{{ $tab->id }}"
                    data-bs-toggle="pill"
                    data-bs-target="#news-tab-content-{{ $tab->id }}"
                    type="button"
                    role="tab"
                    aria-controls="news-tab-content-{{ $tab->id }}"
                    aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                    {{ $tab->name }}
                </button>
            </li>
        @endforeach
    </ul>

    {{-- TAB CONTENT --}}
    <div class="tab-content news-tab-content">

        @foreach($tabs as $tab)
            <div
                class="tab-pane fade {{ $loop->first ? 'show active' : '' }}"
                id="news-tab-content-{{ $tab->id }}"
                role="tabpanel"
                aria-labelledby="news-tab-btn-{{ $tab->id }}">

                <div class="tabpanel_links">

                    @forelse($tab->children as $child)

                        @php
                            $href = '#';

                            if ($child->type === 'external' && !empty($child->url)) {
                                $href = $child->url;
                            } elseif ($child->type === 'file' && !empty($child->file)) {
                                $href = asset('storage/'.$child->file);
                            } elseif (!empty($child->slug)) {
                                $href = route('show.content', $child->slug);
                            }
                        @endphp

                        <a href="{{ $href }}"
                           class="text-decoration-none"
                           @if($child->opens_new_tab || in_array($child->type, ['external', 'file'])) target="_blank" rel="noopener" @endif>

                            <span>
                                {{ $child->name }}

                                @if($child->type === 'file')
                                    <i class="fa fa-file-pdf-o text-danger"></i>
                                @elseif($child->type === 'external')
                                    <i class="fa fa-external-link"></i>
                                @endif
                            </span>

                            <span>➜</span>
                        </a>

                    @empty
                        <div class="p-3 text-muted">
                            No records found.
                        </div>
                    @endforelse

                </div>

            </div>
        @endforeach

    </div>

    <div class="text-end mt-2">
        <a href="{{ url('/') }}" class="btn btn-primary rounded-pill py-2 px-4">
            View more ➜
        </a>
    </div>
</div>

@endif
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    .news-tabs {
    border: 1px solid #28599a;
}

.news-tabs .nav-link {
    border-radius: 0;
    color: #111;
    background: #fff;
    border-right: 1px solid #28599a;
}

.news-tabs .nav-link.active {
    background: #28599a;
    color: #fff;
}

.news-tab-content {
    border: 1px solid #ddd;
    max-height: 200px;
    overflow-y: auto;
    background: #fff;
}

.tabpanel_links a {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 9px 14px;
    border-bottom: 1px solid #28599a;
    color: #111;
}

.tabpanel_links a:hover {
    background: #f4f7ff;
}
</style>