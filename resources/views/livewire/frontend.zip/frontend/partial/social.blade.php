@if(isset($section) && $section->items && $section->items->count())
<section class="social-section py-4">
    <div class="container text-center">
        <h4 class="mb-3">{{ $section->title ?? 'Connect With Us' }}</h4>

        @foreach($section->items as $item)
            <a href="{{ $item->url ?? '#' }}"
               class="btn btn-outline-primary btn-sm m-1"
               target="_blank"
               rel="noopener">
                @if($item->icon)
                    <i class="{{ $item->icon }}"></i>
                @endif
                {{ $item->name }}
            </a>
        @endforeach
    </div>
</section>
@endif
