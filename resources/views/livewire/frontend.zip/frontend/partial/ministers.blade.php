@if(isset($section) && $section->items && $section->items->count())
<section class="ministers-section py-4">
    <div class="container">
        <div class="row g-3">
            @foreach($section->items as $item)
                <div class="col-md-4">
                    <div class="minister-card border rounded p-3 h-100 text-center">
                        @if(!empty($item->image))
                            <img src="{{ asset('storage/' . $item->image) }}"
                                 alt="{{ $item->name }}"
                                 class="img-fluid rounded mb-2">
                        @endif

                        <h5>{{ $item->name }}</h5>

                        @if(!empty($item->description))
                            <p class="mb-0">{{ $item->description }}</p>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
