<div class="container-fluid bg-light py-5">
    <div class="container">

        @foreach($items as $item)

            <div class="row border bg-white rounded p-4 align-items-center mb-4">

                <div class="col-md-2 text-center">
                    @if($item->file_icon)
                        <img
                            src="{{ asset('storage/' . $item->file_icon) }}"
                            alt="{{ $item->name }}"
                            class="img-fluid"
                            style="max-height:200px; object-fit:contain;"
                        >
                    @endif
                </div>

                <div class="col-md-10 minstermaine_heading">
                    {!! $item->content !!}
                </div>

            </div>

        @endforeach

    </div>
</div>