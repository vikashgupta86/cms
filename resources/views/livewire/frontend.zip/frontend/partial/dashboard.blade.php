@if(isset($section) && $section->items && $section->items->count())
<section class="dashboard-stats-section py-5 bg-light">
    <div class="container">
        <div class="row g-3">
            @foreach($section->items as $item)
                <div class="col-6 col-md-3">
                    <div class="stat-card text-center border rounded bg-white p-4 h-100">
                        @if($item->icon)
                            <i class="{{ $item->icon }} fa-2x mb-2"></i>
                        @endif

                        <h3 class="mb-1">
                            {{ $item->badge_text ?? $item->custom_data['value'] ?? '0' }}
                        </h3>

                        <p class="mb-0">{{ $item->name }}</p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
