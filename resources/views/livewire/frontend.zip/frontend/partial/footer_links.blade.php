@if(isset($section) && $section->items && $section->items->count())
<section class="footer-links-section py-4 bg-dark text-white">
    <div class="container">
        <div class="row">
            @foreach($section->items as $item)
                <div class="col-md-3 mb-2">
                    @php
                        $href = $item->type === 'external'
                            ? $item->url
                            : ($item->type === 'file'
                                ? asset('storage/' . ($item->file_path ?? $item->file ?? ''))
                                : route('show.content', $item->slug));
                    @endphp

                    <a href="{{ $href }}"
                       class="text-white text-decoration-none"
                       @if($item->opens_new_tab || $item->type === 'external' || $item->type === 'file') target="_blank" rel="noopener" @endif>
                        {{ $item->name }}
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
